$(document).ready(function() {	
	$('.searchText').keypress(function(e){
 		if(e.which==13){ 			
 		var searchTitle = $('.searchText').val();
 			if(searchTitle===""){
 				var html='<div class="col-lg-6 col-lg-offset-3 "><div class="inner-result">';
          			html+='<p class="text-center">Please enter what you want to search for.</p>';
        			html+='</div></div> '; 
        		return $(".result").html(html);
 			}
  		var html=""; 		
	  	$.ajax({
	 		url:'https://advocatespedia.com/api.php?',	 		 
	 		data: { action:'query',srsearch:searchTitle,	 				 
	 			  list:'search',format:'json',utf8:''},
	 		dataType: 'jsonp',
	 		type:'get',
	 		success: function(jsonp){ 			
	 			for(var i =0 ; i < jsonp.query.search.length; i++){	 				 
	 				html+='<div class="col-lg-6 col-lg-offset-3 "><div class="inner-result">';
          			html+='<a href="https://advocatespedia.com/'+ jsonp.query.search[i].title +'" target="_blank">' ; 
          			html+= jsonp.query.search[i].title +  '</a>'; 
          			html+='<p>' + jsonp.query.search[i].snippet +'</p>';
          			html+='<p>Word Count: <span class="wcount"> '+ jsonp.query.search[i].wordcount + ' words</span> | Size: <span class="size"> '+ Math.floor((jsonp.query.search[i].size)/1024)+' kb </span> </p>';
        			html+='</div></div> '; 
	 			}	 
	 			$(".result").html(html);
	 		}
	 	}); 
 	}		 
		
	}); // end keypress

  	$('.search').on("click",function(){
  		var searchTitle = $('.searchText').val();
 		if(searchTitle===""){
 			var html='<div class="col-lg-6 col-lg-offset-3 "><div class="inner-result">';
          		html+='<p class="text-center">Please enter what you want to search for.</p>';
        		html+='</div></div> '; 
        	return $(".result").html(html);
 		}
  		var html=""; 		
	  	$.ajax({
	 		url:'https://advocatespedia.com/api.php?',	 		 
	 		data: { action:'query',srsearch:searchTitle,	 				 
	 			  list:'search',format:'json',utf8:''},
	 		dataType: 'jsonp',
	 		type:'get',
	 		success: function(jsonp){ 			
	 			for(var i =0 ; i < jsonp.query.search.length; i++){	 				 
	 				html+='<div class="col-lg-6 col-lg-offset-3 "><div class="inner-result">';
          			html+='<a href="https://advocatespedia.com/'+ jsonp.query.search[i].title +'" target="_blank">' ; 
          			html+= jsonp.query.search[i].title +  '</a>'; 
          			html+='<p>' + jsonp.query.search[i].snippet +'</p>';
          			html+='<p>Word Count: <span class="wcount"> '+ jsonp.query.search[i].wordcount + ' words</span> | Size: <span class="size"> '+ Math.floor((jsonp.query.search[i].size)/1024)+' kb </span> </p>';
        			html+='</div></div> '; 
	 			}	 
	 			$(".result").html(html);
	 			
  			}
  		});
  		
	});

});