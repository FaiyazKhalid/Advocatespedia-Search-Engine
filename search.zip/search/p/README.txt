A Pen created at CodePen.io. You can find this one at https://codepen.io/Zaku/pen/EDaun.

 Interactive CodePen Logo.
Created with ParticleSlider.

Responsive & lowers quality for mobile devices.

Hover over logo to interact with particles.
Click to randomize Particles.
Raise Particle-Gap for better performance.

See http://particleslider.com for more information
Issue-Tracker & Feature-Requests: http://dev.zaku.eu/particleslider/issues