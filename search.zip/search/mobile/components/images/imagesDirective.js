'use strict';

function images() {
	return {
		controller: 'ImagesController',
		controllerAs: 'ctrl',
        templateUrl: 'components/images/images.html'
	};
} // images

module.exports = images;
