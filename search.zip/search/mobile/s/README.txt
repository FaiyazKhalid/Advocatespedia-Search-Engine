A Pen created at CodePen.io. You can find this one at https://codepen.io/thepeted/pen/pjqYYv.

 Use the wikipedia 'opensearch' and 'query' API to search for wikipedia articles.  Autosearch powered by [Ajax Autocomplete for jQuery](https://github.com/devbridge/jQuery-Autocomplete).

I created this 'Zipline' exercise whilst working through the FreeCodeCamp Curriculum: http://www.freecodecamp.com/challenges/zipline-build-a-wikipedia-viewer